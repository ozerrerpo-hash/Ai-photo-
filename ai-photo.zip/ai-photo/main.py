"""Command-line entry point.

    python main.py train       --stage autoencoder|dcgan|cgan [--epochs N] [--image-size 128|256]
    python main.py reconstruct                                # Stage A visual comparison
    python main.py generate    --stage dcgan|cgan --num 16 [--class-name cats] [--grid]
"""
from __future__ import annotations

import argparse

from config import Config
from trainers import AutoencoderTrainer, GANTrainer

DEFAULT_SIZE = {"autoencoder": 128, "dcgan": 128, "cgan": 256}  # Stage C targets 256x256
DEFAULT_LR = {"autoencoder": 1e-3, "dcgan": 2e-4, "cgan": 2e-4}


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Modular autoencoder -> DCGAN -> cGAN image system")
    sub = p.add_subparsers(dest="command", required=True)

    def common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--data-dir", default="./my_images")
        sp.add_argument("--ckpt-dir", default="./checkpoints")
        sp.add_argument("--out-dir", default="./outputs")
        sp.add_argument("--image-size", type=int, choices=[64, 128, 256], default=None)
        sp.add_argument("--latent-dim", type=int, default=128)
        sp.add_argument("--base-channels", type=int, default=64)
        sp.add_argument("--batch-size", type=int, default=32)
        sp.add_argument("--num-workers", type=int, default=2)
        sp.add_argument("--device", default="auto")
        sp.add_argument("--seed", type=int, default=42)

    t = sub.add_parser("train", help="train / continue training a stage")
    t.add_argument("--stage", choices=list(DEFAULT_SIZE), required=True)
    t.add_argument("--epochs", type=int, default=50, help="additional epochs for this run")
    t.add_argument("--lr", type=float, default=None)
    t.add_argument("--sample-every", type=int, default=5)
    t.add_argument("--no-augment", action="store_true")
    common(t)

    r = sub.add_parser("reconstruct", help="export original-vs-reconstruction grid (Stage A)")
    r.add_argument("--num", type=int, default=8)
    common(r)

    g = sub.add_parser("generate", help="generate images from a trained GAN/cGAN")
    g.add_argument("--stage", choices=["dcgan", "cgan"], required=True)
    g.add_argument("--num", type=int, default=16)
    g.add_argument("--class-name", default=None, help="class folder name or id (cgan)")
    g.add_argument("--gen-out", default=None, help="output folder (default: outputs/<stage>/generated/...)")
    g.add_argument("--grid", action="store_true", help="also save a grid image")
    g.add_argument("--gen-seed", type=int, default=None, help="seed for reproducible samples")
    common(g)
    return p


def make_config(args: argparse.Namespace, stage: str) -> Config:
    return Config(
        data_dir=args.data_dir,
        ckpt_dir=args.ckpt_dir,
        out_dir=args.out_dir,
        image_size=args.image_size or DEFAULT_SIZE[stage],
        latent_dim=args.latent_dim,
        base_channels=args.base_channels,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=args.device,
        seed=args.seed,
        lr=getattr(args, "lr", None) or DEFAULT_LR[stage],
        epochs=getattr(args, "epochs", 50),
        sample_every=getattr(args, "sample_every", 5),
        augment=not getattr(args, "no_augment", False),
    )


def main() -> None:
    args = build_parser().parse_args()

    if args.command == "train":
        cfg = make_config(args, args.stage)
        trainer = (
            AutoencoderTrainer(cfg)
            if args.stage == "autoencoder"
            else GANTrainer(cfg, conditional=(args.stage == "cgan"))
        )
        trainer.train()
        if args.stage == "autoencoder":
            trainer.export_comparison()

    elif args.command == "reconstruct":
        cfg = make_config(args, "autoencoder")
        AutoencoderTrainer(cfg).export_comparison(n=args.num)

    elif args.command == "generate":
        cfg = make_config(args, args.stage)
        trainer = GANTrainer(cfg, conditional=(args.stage == "cgan"), load_data=False)
        paths = trainer.export_generated(
            args.num, args.class_name, args.gen_out, grid=args.grid, seed=args.gen_seed
        )
        print(f"Saved {len(paths)} files, e.g. {paths[0]}")


if __name__ == "__main__":
    main()
