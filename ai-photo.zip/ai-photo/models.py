"""Stage A/B/C architectures.

All networks scale with `image_size` (64/128/256): the number of stride-2 stages is
log2(image_size) - 2, so the deepest feature map is always 4x4.

* ConvAutoencoder   - Stage A: reconstruction (MSELoss).
* Generator         - Stage B (DCGAN) and Stage C (cGAN, when `num_classes` is given).
* Discriminator     - Stage B (DCGAN) and Stage C (projection-style conditioning via nn.Embedding).
"""
from __future__ import annotations

import math
from typing import List, Optional

import torch
import torch.nn as nn


def _num_stages(image_size: int) -> int:
    n = int(math.log2(image_size)) - 2
    if n < 1 or 2 ** (n + 2) != image_size:
        raise ValueError(f"image_size must be a power of two >= 8, got {image_size}")
    return n


def _channels(base: int, n: int, max_ch: int = 512) -> List[int]:
    """chans[0] = width at 4x4 (largest) ... chans[n] = width at full resolution (= base)."""
    return [min(base * 2 ** (n - i), max_ch) for i in range(n + 1)]


def _down_stack(chans: List[int], use_bn: bool = True) -> nn.Sequential:
    """Full-res -> 4x4 feature extractor (shared by the encoder and the discriminator)."""
    n = len(chans) - 1
    layers: List[nn.Module] = [nn.Conv2d(3, chans[n], 3, 1, 1), nn.LeakyReLU(0.2, True)]
    for i in range(n, 0, -1):
        layers.append(nn.Conv2d(chans[i], chans[i - 1], 4, 2, 1, bias=not use_bn))
        if use_bn:
            layers.append(nn.BatchNorm2d(chans[i - 1]))
        layers.append(nn.LeakyReLU(0.2, True))
    return nn.Sequential(*layers)


def _up_stack(chans: List[int]) -> nn.Sequential:
    """4x4 -> full-res upsampler (shared by the decoder and the generator). Outputs [-1, 1]."""
    n = len(chans) - 1
    layers: List[nn.Module] = []
    for i in range(n):
        layers += [
            nn.ConvTranspose2d(chans[i], chans[i + 1], 4, 2, 1, bias=False),
            nn.BatchNorm2d(chans[i + 1]),
            nn.ReLU(True),
        ]
    layers += [nn.Conv2d(chans[n], 3, 3, 1, 1), nn.Tanh()]
    return nn.Sequential(*layers)


def init_weights(m: nn.Module) -> None:
    """DCGAN-style initialisation: N(0, 0.02)."""
    if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d, nn.Linear, nn.Embedding)):
        nn.init.normal_(m.weight, 0.0, 0.02)
        if getattr(m, "bias", None) is not None:
            nn.init.zeros_(m.bias)
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.normal_(m.weight, 1.0, 0.02)
        nn.init.zeros_(m.bias)


# ----------------------------------------------------------------------------------------
# Stage A
# ----------------------------------------------------------------------------------------
class ConvAutoencoder(nn.Module):
    def __init__(self, image_size: int = 128, latent_dim: int = 128, base_channels: int = 64) -> None:
        super().__init__()
        n = _num_stages(image_size)
        chans = _channels(base_channels, n)
        self.bottleneck_ch = chans[0]
        self.encoder = _down_stack(chans)
        self.fc_enc = nn.Linear(chans[0] * 16, latent_dim)
        self.fc_dec = nn.Sequential(nn.Linear(latent_dim, chans[0] * 16), nn.ReLU(True))
        self.decoder = _up_stack(chans)
        self.apply(init_weights)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc_enc(self.encoder(x).flatten(1))

    def decode(self, z: torch.Tensor) -> torch.Tensor:
        return self.decoder(self.fc_dec(z).view(-1, self.bottleneck_ch, 4, 4))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.decode(self.encode(x))


# ----------------------------------------------------------------------------------------
# Stage B / C
# ----------------------------------------------------------------------------------------
class Generator(nn.Module):
    """DCGAN generator. If `num_classes` is set, the class embedding is concatenated to z (cGAN)."""

    def __init__(
        self,
        latent_dim: int = 128,
        image_size: int = 128,
        base_channels: int = 64,
        num_classes: Optional[int] = None,
        embed_dim: int = 64,
    ) -> None:
        super().__init__()
        n = _num_stages(image_size)
        chans = _channels(base_channels, n)
        self.embed = nn.Embedding(num_classes, embed_dim) if num_classes else None
        in_dim = latent_dim + (embed_dim if self.embed is not None else 0)
        self.project = nn.Sequential(  # 1x1 -> 4x4
            nn.ConvTranspose2d(in_dim, chans[0], 4, 1, 0, bias=False),
            nn.BatchNorm2d(chans[0]),
            nn.ReLU(True),
        )
        self.body = _up_stack(chans)
        self.apply(init_weights)

    def forward(self, z: torch.Tensor, labels: Optional[torch.Tensor] = None) -> torch.Tensor:
        if self.embed is not None:
            if labels is None:
                raise ValueError("Conditional generator requires `labels`")
            z = torch.cat([z, self.embed(labels)], dim=1)
        return self.body(self.project(z[:, :, None, None]))


class Discriminator(nn.Module):
    """Returns raw logits (use BCEWithLogitsLoss). Conditional version uses a projection
    term: logit = fc(h) + <Embedding(y), h>."""

    def __init__(
        self,
        image_size: int = 128,
        base_channels: int = 64,
        num_classes: Optional[int] = None,
    ) -> None:
        super().__init__()
        n = _num_stages(image_size)
        chans = _channels(base_channels, n)
        self.features = _down_stack(chans)
        self.fc = nn.Linear(chans[0], 1)
        self.embed = nn.Embedding(num_classes, chans[0]) if num_classes else None
        self.apply(init_weights)

    def forward(self, x: torch.Tensor, labels: Optional[torch.Tensor] = None) -> torch.Tensor:
        h = self.features(x).mean(dim=(2, 3))
        out = self.fc(h)
        if self.embed is not None:
            if labels is None:
                raise ValueError("Conditional discriminator requires `labels`")
            out = out + (self.embed(labels) * h).sum(dim=1, keepdim=True)
        return out.squeeze(1)
