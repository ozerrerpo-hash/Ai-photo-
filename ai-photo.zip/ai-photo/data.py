"""Stage 1 - Data pipeline.

* Recursively scans a folder for images (.jpg/.jpeg/.png/.bmp/.webp).
* Converts everything to RGB (handles RGBA, palette, grayscale).
* Resizes uniformly (aspect-preserving resize + centre crop, or random-resized crop when augmenting).
* Normalises to [-1, 1] to match the Tanh output of the decoder/generator.
* Class labels come from first-level sub-folders: my_images/cats/*.jpg -> class "cats".
  Images placed directly in the root belong to class "default".
* `class_to_idx` can be passed in (restored from a checkpoint) so label ids stay stable
  across runs; new folders are appended with new ids (up to `max_classes`).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms as T

log = logging.getLogger("imgsys.data")

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def build_transforms(image_size: int, augment: bool) -> T.Compose:
    """Training transforms (augment=True) or deterministic eval transforms."""
    if augment:
        ops = [
            T.RandomResizedCrop(image_size, scale=(0.8, 1.0), ratio=(0.9, 1.1)),
            T.RandomHorizontalFlip(),
            T.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1),
        ]
    else:
        ops = [T.Resize(image_size), T.CenterCrop(image_size)]
    ops += [T.ToTensor(), T.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]
    return T.Compose(ops)


class ImageFolderDataset(Dataset):
    """Dynamic dataset: re-scans the folder every time it is created, so new images
    dropped into the folder are picked up on the next run."""

    def __init__(
        self,
        root: Path,
        image_size: int = 128,
        augment: bool = True,
        class_to_idx: Optional[Dict[str, int]] = None,
        max_classes: int = 64,
    ) -> None:
        self.root = Path(root)
        if not self.root.is_dir():
            raise FileNotFoundError(f"Image folder not found: {self.root.resolve()}")

        self.paths: List[Path] = sorted(
            p for p in self.root.rglob("*") if p.is_file() and p.suffix.lower() in IMG_EXTS
        )
        if not self.paths:
            raise RuntimeError(f"No images {sorted(IMG_EXTS)} found in {self.root.resolve()}")

        names = [self._class_name(p) for p in self.paths]
        self.class_to_idx: Dict[str, int] = dict(class_to_idx or {})
        for name in sorted(set(names)):
            if name not in self.class_to_idx:
                if len(self.class_to_idx) >= max_classes:
                    raise ValueError(f"More than max_classes={max_classes} class folders")
                self.class_to_idx[name] = len(self.class_to_idx)
        self.labels: List[int] = [self.class_to_idx[n] for n in names]
        self.transform = build_transforms(image_size, augment)

    def _class_name(self, path: Path) -> str:
        rel = path.relative_to(self.root)
        return rel.parts[0] if len(rel.parts) > 1 else "default"

    def relative_files(self) -> List[str]:
        return [p.relative_to(self.root).as_posix() for p in self.paths]

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        # Skip unreadable/corrupt files instead of crashing a long training run.
        for attempt in range(5):
            j = (idx + attempt) % len(self.paths)
            try:
                with Image.open(self.paths[j]) as img:
                    img = img.convert("RGB")
                return self.transform(img), self.labels[j]
            except Exception as exc:  # noqa: BLE001
                log.warning("Skipping unreadable image %s (%s)", self.paths[j], exc)
        raise RuntimeError("Too many consecutive unreadable images")


def build_dataloader(ds: Dataset, batch_size: int, num_workers: int, pin_memory: bool) -> DataLoader:
    bs = min(batch_size, len(ds))
    return DataLoader(
        ds,
        batch_size=bs,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=len(ds) > bs,  # avoid a size-1 last batch breaking BatchNorm
        persistent_workers=num_workers > 0,
    )
