"""Logging, seeding, loss-curve plotting and image export helpers (Stage 4)."""
from __future__ import annotations

import logging
import random
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib

matplotlib.use("Agg")  # headless-safe backend
import matplotlib.pyplot as plt
import numpy as np
import torch
from torchvision.utils import save_image


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_logger(name: str, log_file: Optional[Path] = None) -> logging.Logger:
    """Console + optional file logger (no duplicate handlers on repeated calls)."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%H:%M:%S")
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        logger.addHandler(sh)
        if log_file is not None:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(fmt)
            logger.addHandler(fh)
    return logger


def denormalize(x: torch.Tensor) -> torch.Tensor:
    """[-1, 1] -> [0, 1]."""
    return (x * 0.5 + 0.5).clamp(0, 1)


def plot_loss_curves(history: Dict[str, List[float]], path: Path, title: str) -> None:
    """Save one figure with every metric in `history` plotted against the epoch number."""
    if not history or not any(history.values()):
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    for name, values in history.items():
        ax.plot(range(1, len(values) + 1), values, label=name, linewidth=1.8)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


class ImageExporter:
    """Clean export of single images, batches (one file each) and grids."""

    @staticmethod
    def save_grid(images: torch.Tensor, path: Path, nrow: int = 8) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        save_image(denormalize(images.detach().cpu()), path, nrow=nrow, padding=2)
        return path

    @staticmethod
    def save_single(image: torch.Tensor, path: Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        save_image(denormalize(image.detach().cpu()), path)
        return path

    @staticmethod
    def save_batch(images: torch.Tensor, folder: Path, prefix: str = "img", ext: str = ".png") -> List[Path]:
        """Saves each image as its own file; numbering continues after existing files."""
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        start = len(list(folder.glob(f"{prefix}_*{ext}")))
        return [
            ImageExporter.save_single(img, folder / f"{prefix}_{start + i:04d}{ext}")
            for i, img in enumerate(images)
        ]
