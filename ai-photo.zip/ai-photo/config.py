"""Central configuration for the image system.

A single dataclass keeps every hyper-parameter in one place, validates it, and can be
serialised into checkpoints so a resumed run can verify architectural compatibility.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path

import torch

VALID_SIZES = (64, 128, 256)  # powers of two; the spec targets 128..256


@dataclass
class Config:
    # --- paths ---
    data_dir: Path = Path("./my_images")
    ckpt_dir: Path = Path("./checkpoints")
    out_dir: Path = Path("./outputs")

    # --- data ---
    image_size: int = 128          # 128 or 256 (64 also works for quick tests)
    batch_size: int = 32
    augment: bool = True
    num_workers: int = 2           # set 0 on Windows if you hit multiprocessing errors
    max_classes: int = 64          # embedding capacity: new class folders can be added later

    # --- model ---
    latent_dim: int = 128
    base_channels: int = 64
    embed_dim: int = 64            # class-embedding width for the cGAN

    # --- optimisation ---
    epochs: int = 50               # ADDITIONAL epochs for this run (resume-friendly)
    lr: float = 2e-4
    beta1: float = 0.5

    # --- monitoring ---
    sample_every: int = 5          # epochs between preview images
    save_every: int = 1            # epochs between checkpoint writes
    seed: int = 42
    device: str = "auto"           # auto | cpu | cuda | mps

    def __post_init__(self) -> None:
        self.data_dir = Path(self.data_dir)
        self.ckpt_dir = Path(self.ckpt_dir)
        self.out_dir = Path(self.out_dir)
        if self.image_size not in VALID_SIZES:
            raise ValueError(f"image_size must be one of {VALID_SIZES}, got {self.image_size}")
        if self.batch_size < 2:
            raise ValueError("batch_size must be >= 2 (BatchNorm needs more than one sample)")

    def resolve_device(self) -> torch.device:
        if self.device != "auto":
            return torch.device(self.device)
        if torch.cuda.is_available():
            return torch.device("cuda")
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def to_dict(self) -> dict:
        """JSON/`weights_only`-safe dict (paths become strings)."""
        d = asdict(self)
        for k in ("data_dir", "ckpt_dir", "out_dir"):
            d[k] = str(d[k])
        return d
