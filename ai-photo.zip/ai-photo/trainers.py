"""Trainers for all three stages, with checkpoint-based continuous learning.

Class hierarchy
    BaseTrainer (ABC)      - data loading, checkpoint save/resume, epoch loop, logging, curves
      |- AutoencoderTrainer  - Stage A
      |- GANTrainer          - Stage B (conditional=False) and Stage C (conditional=True)

Incremental learning
    On startup the trainer looks for  <ckpt_dir>/<stage>_<size>px.pth.
    * found    -> weights, optimizer states, loss history, epoch counter and the
                  class-name -> id map are restored; training continues on the *current*
                  contents of the image folder (old + new images).
    * missing  -> everything is initialised from scratch.
    `epochs` always means "additional epochs for this run".
"""
from __future__ import annotations

import csv
import os
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import Config
from data import ImageFolderDataset, build_dataloader
from models import ConvAutoencoder, Discriminator, Generator
from utils import ImageExporter, get_logger, plot_loss_curves, set_seed


class CheckpointManager:
    """Atomic save (tmp file + rename) so a crash never corrupts the checkpoint."""

    @staticmethod
    def save(payload: dict, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        torch.save(payload, tmp)
        os.replace(tmp, path)

    @staticmethod
    def load(path: Path, device: torch.device) -> Optional[dict]:
        if not path.is_file():
            return None
        return torch.load(path, map_location=device, weights_only=True)


class BaseTrainer(ABC):
    stage_name: str = "base"

    def __init__(self, cfg: Config, load_data: bool = True) -> None:
        self.cfg = cfg
        self.device = cfg.resolve_device()
        set_seed(cfg.seed)

        self.out_dir = cfg.out_dir / self.stage_name
        self.ckpt_path = cfg.ckpt_dir / f"{self.stage_name}_{cfg.image_size}px.pth"
        self.log = get_logger(f"imgsys.{self.stage_name}", self.out_dir / "train.log")

        self.history: Dict[str, List[float]] = {}
        self.epoch = 0  # completed epochs (across all runs)

        # 1) Look for existing knowledge
        ckpt = CheckpointManager.load(self.ckpt_path, self.device)
        self.class_to_idx: Dict[str, int] = dict(ckpt["class_to_idx"]) if ckpt else {}
        previously_seen = set(ckpt["seen_files"]) if ckpt else set()

        # 2) Data (re-scanned every run => new images are picked up automatically)
        self.dataset: Optional[ImageFolderDataset] = None
        self.loader = None
        self.seen_files: List[str] = sorted(previously_seen)
        if load_data:
            self.dataset = ImageFolderDataset(
                cfg.data_dir, cfg.image_size, cfg.augment, self.class_to_idx, cfg.max_classes
            )
            self.class_to_idx = self.dataset.class_to_idx
            self.loader = build_dataloader(
                self.dataset, cfg.batch_size, cfg.num_workers, self.device.type == "cuda"
            )
            current = set(self.dataset.relative_files())
            self.seen_files = sorted(current | previously_seen)
            new = len(current - previously_seen) if ckpt else len(current)
            self.log.info(
                "Dataset: %d images, %d classes %s (%d new since last run)",
                len(self.dataset), len(self.class_to_idx), list(self.class_to_idx), new,
            )
        elif ckpt is None:
            raise FileNotFoundError(f"No checkpoint at {self.ckpt_path} and no data to train on")

        # 3) Models, then restore weights if a checkpoint exists
        self.build_models()
        if ckpt is not None:
            if ckpt.get("arch") != self.arch():
                raise ValueError(
                    f"Checkpoint architecture {ckpt.get('arch')} != requested {self.arch()}. "
                    "Use the same --latent-dim/--base-channels/--image-size or a new --ckpt-dir."
                )
            self.load_state(ckpt)
            self.history = {k: list(v) for k, v in ckpt["history"].items()}
            self.epoch = int(ckpt["epoch"])
            self.log.info("Resumed from %s (epoch %d) - previous knowledge preserved", self.ckpt_path, self.epoch)
        else:
            self.log.info("No checkpoint at %s - training from scratch", self.ckpt_path)

    # ---- hooks each stage implements -------------------------------------------------
    @abstractmethod
    def build_models(self) -> None: ...

    @abstractmethod
    def state_payload(self) -> dict: ...

    @abstractmethod
    def load_state(self, ckpt: dict) -> None: ...

    @abstractmethod
    def train_one_epoch(self, epoch: int) -> Dict[str, float]: ...

    def on_epoch_end(self, epoch: int) -> None:
        """Optional: export preview images etc."""

    def arch(self) -> dict:
        c = self.cfg
        return {"image_size": c.image_size, "latent_dim": c.latent_dim, "base_channels": c.base_channels}

    # ---- shared machinery --------------------------------------------------------------
    def save(self) -> None:
        payload = {
            "stage": self.stage_name,
            "epoch": self.epoch,
            "arch": self.arch(),
            "config": self.cfg.to_dict(),
            "history": self.history,
            "class_to_idx": self.class_to_idx,
            "seen_files": self.seen_files,
        }
        payload.update(self.state_payload())
        CheckpointManager.save(payload, self.ckpt_path)

    def plot_curves(self) -> Path:
        path = self.out_dir / "loss_curves.png"
        plot_loss_curves(self.history, path, f"{self.stage_name} training loss ({self.cfg.image_size}px)")
        return path

    def _log_csv(self, epoch: int, metrics: Dict[str, float]) -> None:
        path = self.out_dir / "metrics.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        new_file = not path.exists()
        with open(path, "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["epoch", *metrics.keys()])
            w.writerow([epoch, *[f"{v:.6f}" for v in metrics.values()]])

    def train(self, epochs: Optional[int] = None) -> None:
        epochs = epochs or self.cfg.epochs
        target = self.epoch + epochs
        self.log.info("Training epochs %d -> %d on %s", self.epoch + 1, target, self.device)
        try:
            for ep in range(self.epoch + 1, target + 1):
                t0 = time.time()
                metrics = self.train_one_epoch(ep)
                for k, v in metrics.items():
                    self.history.setdefault(k, []).append(v)
                self.epoch = ep
                self.log.info(
                    "Epoch %d/%d | %s | %.1fs", ep, target,
                    " | ".join(f"{k}={v:.4f}" for k, v in metrics.items()), time.time() - t0,
                )
                self._log_csv(ep, metrics)
                self.on_epoch_end(ep)
                if ep % self.cfg.save_every == 0:
                    self.save()
                    self.plot_curves()
        except KeyboardInterrupt:
            self.log.warning("Interrupted - saving progress")
        self.save()
        self.log.info("Loss curves: %s | checkpoint: %s", self.plot_curves(), self.ckpt_path)


# ========================================================================================
# Stage A - Autoencoder
# ========================================================================================
class AutoencoderTrainer(BaseTrainer):
    stage_name = "autoencoder"

    def build_models(self) -> None:
        c = self.cfg
        self.model = ConvAutoencoder(c.image_size, c.latent_dim, c.base_channels).to(self.device)
        self.opt = torch.optim.Adam(self.model.parameters(), lr=c.lr, betas=(c.beta1, 0.999))
        self.criterion = nn.MSELoss()
        self._eval_ds: Optional[ImageFolderDataset] = None

    def state_payload(self) -> dict:
        return {"model": self.model.state_dict(), "opt": self.opt.state_dict()}

    def load_state(self, ckpt: dict) -> None:
        self.model.load_state_dict(ckpt["model"])
        self.opt.load_state_dict(ckpt["opt"])

    def train_one_epoch(self, epoch: int) -> Dict[str, float]:
        self.model.train()
        total, count = 0.0, 0
        for imgs, _ in self.loader:
            imgs = imgs.to(self.device, non_blocking=True)
            loss = self.criterion(self.model(imgs), imgs)
            self.opt.zero_grad(set_to_none=True)
            loss.backward()
            self.opt.step()
            total += loss.item() * imgs.size(0)
            count += imgs.size(0)
        return {"mse": total / count}

    @torch.no_grad()
    def export_comparison(self, n: int = 8, path: Optional[Path] = None) -> Path:
        """Top row: originals. Bottom row: reconstructions. Same images every call (seeded)."""
        if self._eval_ds is None:
            self._eval_ds = ImageFolderDataset(
                self.cfg.data_dir, self.cfg.image_size, False, self.class_to_idx, self.cfg.max_classes
            )
        ds = self._eval_ds
        g = torch.Generator().manual_seed(self.cfg.seed)
        idx = torch.randperm(len(ds), generator=g)[: min(n, len(ds))].tolist()
        x = torch.stack([ds[i][0] for i in idx]).to(self.device)
        was_training = self.model.training
        self.model.eval()
        recon = self.model(x)
        self.model.train(was_training)
        mse = F.mse_loss(recon, x).item()
        path = path or self.out_dir / "reconstruction_comparison.png"
        ImageExporter.save_grid(torch.cat([x, recon]), path, nrow=len(idx))
        self.log.info("Comparison saved to %s (MSE %.5f)", path, mse)
        return path

    def on_epoch_end(self, epoch: int) -> None:
        if epoch % self.cfg.sample_every == 0:
            self.export_comparison(path=self.out_dir / "comparisons" / f"epoch_{epoch:04d}.png")


# ========================================================================================
# Stage B / C - DCGAN and conditional GAN
# ========================================================================================
class GANTrainer(BaseTrainer):
    def __init__(self, cfg: Config, conditional: bool = False, load_data: bool = True) -> None:
        self.conditional = conditional
        self.stage_name = "cgan" if conditional else "dcgan"
        super().__init__(cfg, load_data)

    def arch(self) -> dict:
        a = super().arch()
        if self.conditional:
            a.update(embed_dim=self.cfg.embed_dim, max_classes=self.cfg.max_classes)
        return a

    def build_models(self) -> None:
        c = self.cfg
        n_cls = c.max_classes if self.conditional else None
        self.G = Generator(c.latent_dim, c.image_size, c.base_channels, n_cls, c.embed_dim).to(self.device)
        self.D = Discriminator(c.image_size, c.base_channels, n_cls).to(self.device)
        self.opt_g = torch.optim.Adam(self.G.parameters(), lr=c.lr, betas=(c.beta1, 0.999))
        self.opt_d = torch.optim.Adam(self.D.parameters(), lr=c.lr, betas=(c.beta1, 0.999))
        self.criterion = nn.BCEWithLogitsLoss()

        # Fixed noise/labels -> previews are comparable across epochs.
        self.n_preview = 32
        gen = torch.Generator().manual_seed(c.seed)
        self.fixed_z = torch.randn(self.n_preview, c.latent_dim, generator=gen).to(self.device)
        n_known = max(len(self.class_to_idx), 1)
        self.fixed_labels = (torch.arange(self.n_preview) % n_known).to(self.device)

    def state_payload(self) -> dict:
        return {
            "G": self.G.state_dict(), "D": self.D.state_dict(),
            "opt_g": self.opt_g.state_dict(), "opt_d": self.opt_d.state_dict(),
        }

    def load_state(self, ckpt: dict) -> None:
        self.G.load_state_dict(ckpt["G"])
        self.D.load_state_dict(ckpt["D"])
        self.opt_g.load_state_dict(ckpt["opt_g"])
        self.opt_d.load_state_dict(ckpt["opt_d"])

    def train_one_epoch(self, epoch: int) -> Dict[str, float]:
        self.G.train()
        self.D.train()
        sum_d = sum_g = 0.0
        count = 0
        for real, labels in self.loader:
            real = real.to(self.device, non_blocking=True)
            labels = labels.to(self.device, non_blocking=True) if self.conditional else None
            b = real.size(0)
            ones = torch.full((b,), 0.9, device=self.device)  # one-sided label smoothing
            zeros = torch.zeros(b, device=self.device)

            # --- discriminator step ---
            z = torch.randn(b, self.cfg.latent_dim, device=self.device)
            fake = self.G(z, labels).detach()
            loss_d = self.criterion(self.D(real, labels), ones) + self.criterion(self.D(fake, labels), zeros)
            self.opt_d.zero_grad(set_to_none=True)
            loss_d.backward()
            self.opt_d.step()

            # --- generator step ---
            z = torch.randn(b, self.cfg.latent_dim, device=self.device)
            fake = self.G(z, labels)
            loss_g = self.criterion(self.D(fake, labels), torch.ones(b, device=self.device))
            self.opt_g.zero_grad(set_to_none=True)
            loss_g.backward()
            self.opt_g.step()

            sum_d += loss_d.item() * b
            sum_g += loss_g.item() * b
            count += b
        return {"D_loss": sum_d / count, "G_loss": sum_g / count}

    # ---- generation / export ----------------------------------------------------------
    def resolve_class(self, class_name: Union[str, int, None]) -> Optional[int]:
        if not self.conditional or class_name is None:
            return None
        if isinstance(class_name, int) or str(class_name).isdigit():
            idx = int(class_name)
            if idx not in self.class_to_idx.values():
                raise ValueError(f"Unknown class id {idx}. Known: {self.class_to_idx}")
            return idx
        if class_name not in self.class_to_idx:
            raise ValueError(f"Unknown class '{class_name}'. Known classes: {list(self.class_to_idx)}")
        return self.class_to_idx[class_name]

    @torch.no_grad()
    def generate(self, num: int = 16, class_name: Union[str, int, None] = None, seed: Optional[int] = None) -> torch.Tensor:
        """Returns `num` images in [-1, 1] on the CPU. For the cGAN, pass a class name/id
        (or None for a random mix of the known classes)."""
        idx = self.resolve_class(class_name)
        gen = torch.Generator().manual_seed(seed) if seed is not None else None
        was_training = self.G.training
        self.G.eval()
        out = []
        for start in range(0, num, 32):
            b = min(32, num - start)
            z = torch.randn(b, self.cfg.latent_dim, generator=gen).to(self.device)
            labels = None
            if self.conditional:
                labels = (
                    torch.full((b,), idx, dtype=torch.long)
                    if idx is not None
                    else torch.randint(0, len(self.class_to_idx), (b,), generator=gen)
                ).to(self.device)
            out.append(self.G(z, labels).cpu())
        self.G.train(was_training)
        return torch.cat(out)

    def export_generated(
        self,
        num: int = 16,
        class_name: Union[str, int, None] = None,
        out_dir: Optional[Path] = None,
        grid: bool = True,
        seed: Optional[int] = None,
    ) -> List[Path]:
        """Saves each image as a separate PNG (+ an optional grid) in a dedicated folder."""
        images = self.generate(num, class_name, seed)
        tag = str(class_name) if class_name is not None and self.conditional else "random"
        folder = Path(out_dir) if out_dir else self.out_dir / "generated" / tag
        paths = ImageExporter.save_batch(images, folder, prefix=tag)
        if grid:
            paths.append(ImageExporter.save_grid(images, folder / f"grid_{int(time.time())}.png", nrow=min(8, num)))
        self.log.info("Saved %d generated images to %s", num, folder)
        return paths

    def on_epoch_end(self, epoch: int) -> None:
        if epoch % self.cfg.sample_every == 0:
            self.G.eval()
            with torch.no_grad():
                fake = self.G(self.fixed_z, self.fixed_labels if self.conditional else None)
            self.G.train()
            ImageExporter.save_grid(fake, self.out_dir / "samples" / f"epoch_{epoch:04d}.png", nrow=8)
