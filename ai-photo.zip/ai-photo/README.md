# Autoencoder → DCGAN → cGAN image system (PyTorch)

## Setup
```bash
pip install "torch>=2.0" torchvision matplotlib pillow numpy
```

## Layout
| File | Role |
|---|---|
| `config.py` | `Config` dataclass: every hyper-parameter, validated, saved into checkpoints |
| `data.py` | `ImageFolderDataset` (RGB, resize/crop, augmentation, [-1,1] normalisation, stable class ids) |
| `models.py` | `ConvAutoencoder`, `Generator`, `Discriminator` (scale with 64/128/256 px) |
| `trainers.py` | `CheckpointManager`, `BaseTrainer`, `AutoencoderTrainer`, `GANTrainer` |
| `utils.py` | logging, seeding, loss-curve plots, `ImageExporter` |
| `main.py` | CLI: `train`, `reconstruct`, `generate` |

## Data layout
```
my_images/
  cats/ a.jpg b.png ...      # sub-folder name = class (used by the cGAN)
  dogs/ ...
  loose.jpg                  # files in the root belong to class "default"
```
Plain `.jpg/.jpeg/.png/.bmp/.webp` are accepted; RGBA/grayscale are converted to RGB; unreadable files are skipped with a warning.

## Stage A – Autoencoder
```bash
python main.py train --stage autoencoder --epochs 50 --image-size 128
python main.py reconstruct --num 8
```
Encoder (strided convs → 4×4 → latent vector) and decoder (transposed convs, Tanh). Loss: `MSELoss`.
Outputs in `outputs/autoencoder/`: `loss_curves.png`, `metrics.csv`, `train.log`,
`comparisons/epoch_XXXX.png` and `reconstruction_comparison.png` (top row originals, bottom row reconstructions).

## Stage B – DCGAN (unconditional)
```bash
python main.py train --stage dcgan --epochs 100 --image-size 128
python main.py generate --stage dcgan --num 16 --grid
```
Generator: noise → 4×4 → transposed-conv blocks (BatchNorm + ReLU) → Tanh. Discriminator: strided convs
(BatchNorm + LeakyReLU) → logit. `BCEWithLogitsLoss`, Adam(2e-4, β1=0.5), one-sided label smoothing (0.9).
Previews from fixed noise are written to `outputs/dcgan/samples/` so progress is comparable across epochs.

## Stage C – Conditional GAN (256×256)
```bash
python main.py train --stage cgan --epochs 200            # defaults to 256px
python main.py generate --stage cgan --class-name cats --num 8 --grid
python main.py generate --stage cgan --num 16            # random mix of known classes
```
The generator concatenates `nn.Embedding(class) ` to the noise vector; the discriminator uses projection
conditioning with its own `nn.Embedding`. Generated images land in `outputs/cgan/generated/<class>/`
(or a folder you give with `--gen-out`).

## Continuous / incremental learning
* Checkpoints: `checkpoints/<stage>_<size>px.pth` (weights, optimizer states, epoch counter, loss history,
  class map, list of seen files). Saved atomically after every epoch (`save_every`) and on Ctrl-C.
* Re-run the same `train` command any time: if the file exists it is loaded, otherwise training starts from scratch.
  `--epochs` is always the number of **additional** epochs; loss curves continue across runs.
* New images/folders are picked up automatically (the folder is re-scanned each run; the log reports how many are new).
* New classes get the next free id. The embedding has room for `max_classes` (default 64), so you can add class folders later without changing the architecture.
* Keep the older images in the folder: training always runs over the *whole* folder, which is what protects
  earlier knowledge from being forgotten. Training only on a tiny new batch will drift the weights toward it.
* Changing `--image-size`, `--latent-dim` or `--base-channels` means a different architecture → separate checkpoint (size is in the file name) or a clear error.

## Tips
* Start with 64–128 px and a few hundred images to verify the loop, then scale up. 256 px cGAN training wants a GPU.
* Windows: if DataLoader workers misbehave, add `--num-workers 0`.
* GAN losses are not a quality score: judge progress mainly from the sample grids.
